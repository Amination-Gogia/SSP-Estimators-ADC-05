#ifndef configuring_inputs_types_h_
#define configuring_inputs_types_h_
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
typedef struct mtpbypmub4e_ mtpbypmub4e ; typedef struct m5xks5eepa
hxg1owdhqb ;
#endif
