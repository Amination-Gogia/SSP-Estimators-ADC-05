#ifndef configuring_inputs_capi_h_
#define configuring_inputs_capi_h_
#include "configuring_inputs.h"
extern void configuring_inputs_InitializeDataMapInfo ( hxg1owdhqb * const
g0tuafjos4 , void * sysRanPtr , int contextTid ) ;
#endif
